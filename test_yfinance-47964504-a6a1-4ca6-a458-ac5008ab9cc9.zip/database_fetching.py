import json
import boto3
from boto3.dynamodb.conditions import Key

# Initializing the DynamoDB Client
dynamodb = boto3.resource('dynamodb')
stock_exchange = 'stock_exchange'
stock_ticker = 'stock_ticker'
table_stock_exchange = dynamodb.Table(stock_exchange)
table_stock_ticker = dynamodb.Table(stock_ticker)

def data_fetching(event, context):
    # Print event for debugging
    print("Received event: ", json.dumps(event))

    try:
        # Extract values
        stock_name = event['Stock']
        exchange = event['Country']  # Assuming 'Country' refers to the exchange

        if not stock_name or not exchange:
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'Both "Stock" and "Country" fields are required.'})
            }
        
        print(f"Stock name: {stock_name}, Exchange: {exchange}")

    except KeyError as e:
        return {
            'statusCode': 400,
            'body': json.dumps({'error': f'Missing required parameter: {str(e)}'})
        }

    # Query DynamoDB for ticker information
    response_ticker = table_stock_ticker.query(
        KeyConditionExpression=Key('stock').eq(stock_name)
    )

    # Query DynamoDB for exchange information
    response_exchange = table_stock_exchange.query(
        KeyConditionExpression=Key('exchange').eq(exchange)
    )

    # Check if both queries return results
    if response_ticker.get('Items') and response_exchange.get('Items'):
        ticker_item = response_ticker['Items'][0]
        exchange_item = response_exchange['Items'][0]

        ticker_value = ticker_item.get('ticker', 'No data for ticker')
        exchange_name = exchange_item.get('exchange_name', 'No data for exchange')

        print(f'ticker_value: {ticker_value}, exchange_name: {exchange_name}')

        responseBody = {
            'ticker': ticker_value,
            'exchange': exchange_name
        }

        return {
            'statusCode': 200,
            'body': json.dumps(responseBody)
        }
    else:
        return {
            'statusCode': 404,
            'body': json.dumps({'error': 'Stock ticker or exchange not found in DynamoDB.'})
        }