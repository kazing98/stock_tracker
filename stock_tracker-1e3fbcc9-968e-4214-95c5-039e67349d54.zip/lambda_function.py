import requests
from bs4 import BeautifulSoup
import json
import boto3

lambdaClient = boto3.client('lambda')

def lambda_handler(event, context):
    print("Received event: ", json.dumps(event))
    
    # Handle preflight OPTIONS request
    if event.get('httpMethod') == 'OPTIONS':
        return handle_options_request()

    # Extract query parameters
    params = event.get("queryStringParameters", {}) or {}
    country = params.get("country")
    stock = params.get("stock")
    date = params.get("date")
    time_range = params.get("time_range") or '1D'

    # Validate parameters
    if not all([country, stock, date]):
        return response(400, "Missing required parameters.")

    input_data = {
        'Stock': stock,
        'Country': country
    }

    # Invoke second Lambda function
    try:
        response_lambda = lambdaClient.invoke(
            FunctionName='arn:aws:lambda:eu-west-1:559050216210:function:test_yfinance',
            InvocationType='RequestResponse',
            Payload=json.dumps(input_data)
        )

        response_payload = json.load(response_lambda['Payload'])
        print("Response payload from second Lambda:", response_payload)

        body = json.loads(response_payload.get('body', '{}'))
        exchange = body.get('exchange')
        ticker = body.get('ticker')

        if not exchange or not ticker:
            return response(500, "Failed to retrieve exchange or ticker data.")

        # Scrape stock data from Google Finance
        url = f'https://www.google.com/finance/quote/{ticker}:{exchange}?hl=en&window={time_range}'
        soup = BeautifulSoup(requests.get(url).text, 'html.parser')

        price_tag = soup.find(class_='YMlKec fxKbKc')
        previous_close_tag = soup.find(class_='P6K39c')
        # stock_details_tag = soup.find(class_='ygUjEc')

        if not price_tag or not previous_close_tag:
            return response(500, "Failed to extract stock data.")

        price = price_tag.text.strip().replace(",", "")
        previous_close = previous_close_tag.text.strip().replace(",", "")
        # stock_details = stock_details_tag.text.replace("\u202f", " ")

        # return response(200, {"stock": stock, "price": price, "previous_close": previous_close, "stock_details" : stock_details})
        return response(200, {'Date': date, "Stock": stock, "Current Price": price, "Previous Close": previous_close})

    except Exception as e:
        print("Error:", str(e))
        return response(500, {"message": "Internal Server Error", "error": str(e)})

# Function to handle preflight OPTIONS request
def handle_options_request():
    return {
        "statusCode": 200,
        "headers": {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "Content-Type, Authorization",
            "Access-Control-Allow-Methods": "GET, POST, OPTIONS"
        },
        "body": ""
    }

# Response helper function
def response(status, data):
    return {
        "statusCode": status,
        "headers": {
            "Access-Control-Allow-Origin": "*",  # Allow all origins
            "Access-Control-Allow-Headers": "Content-Type, Authorization",
            "Access-Control-Allow-Methods": "GET, POST, OPTIONS"
        },
        "body": json.dumps(data)
    }